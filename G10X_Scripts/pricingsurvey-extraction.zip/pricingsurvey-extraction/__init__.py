from .extraction_app import funcextraction  # Import the main logic from the file where it is defined
import logging
import azure.functions as func
# from .extraction_app import main as extraction_main

# Create the FunctionApp instance with HTTP function-level authorization
# app = func.FunctionApp(http_auth_level=func.AuthLevel.FUNCTION)
app = func.FunctionApp()
@app.function_name(name="funcextraction")
@app.route(route="funcextraction", auth_level=func.AuthLevel.FUNCTION)
def run_funcextraction(req: func.HttpRequest) -> func.HttpResponse:
    logging.info('Python HTTP trigger function processed a request.')
    return funcextraction(req)  # Call the main logic function from some_name.py
