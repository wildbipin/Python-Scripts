"""Image Extraction Azure Function Overview -
This Azure Function is designed to process images, extract text related to competitor information and promotional details from pub industry pricing menus, and store the extracted information in an Azure SQL database."""

import logging
import os
import requests
import base64
import io
import pyodbc
from PIL import Image
from azure.functions import HttpRequest, HttpResponse
from pillow_heif import register_heif_opener

# Register HEIF opener with Pillow to handle HEIC images
register_heif_opener()

class ImageProcessor:
    def __init__(self, image_path):
        """Initialize the ImageProcessor with the path to the image."""
        self.image_path = image_path
        self.image = None

    def load_image(self):
        """Load the image from the specified path."""
        try:
            self.image = Image.open(self.image_path)
        except Exception as e:
            logging.error(f"Failed to load image at {self.image_path}: {e}")
            raise ValueError("Failed to load image. Please check the image path and format.")

    def convert_to_png(self):
        """Convert the loaded image to PNG format and return the path to the saved image."""
        if self.image is not None:
            png_path = self.image_path.rsplit('.', 1)[0] + '.png'
            self.image.convert('RGBA').save(png_path, "PNG")
            return png_path
        else:
            raise ValueError("Image not loaded. Call load_image() first.")

    def encode_image_to_base64(self):
        """Encode the loaded image as a base64 string."""
        if self.image is not None:
            buffered = io.BytesIO()
            self.image.convert('RGBA').save(buffered, format="PNG")
            return base64.b64encode(buffered.getvalue()).decode('ascii')
        else:
            raise ValueError("Image not loaded. Call load_image() first.")

    def validate_image_format(self):
        """Validate that the image format is supported."""
        valid_formats = ('.jpg', '.jpeg', '.png', '.gif', '.bmp', 
                        '.tiff', '.tif', '.heic', '.webp', 
                        '.tga', '.ppm', '.ico', '.eps')
        if not self.image_path.lower().endswith(valid_formats):
            raise ValueError("Unsupported image format. Please use one of the following: " + ", ".join(valid_formats))

def create_table_if_not_exists():
    """Create the ExtractedTexts table in the Azure SQL database if it doesn't already exist."""
    conn_str = os.getenv('SQL_CONNECTION_STRING')
    create_table_sql = """
    IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='ExtractedTexts' AND xtype='U')
    CREATE TABLE ExtractedTexts (
        Id INT IDENTITY(1,1) PRIMARY KEY,
        Text NVARCHAR(MAX),
        CreatedAt DATETIME DEFAULT GETDATE()
    );
    """
    try:
        with pyodbc.connect(conn_str) as conn:
            cursor = conn.cursor()
            cursor.execute(create_table_sql)
            conn.commit()
    except Exception as e:
        logging.error(f"Database connection error: {e}")
        raise RuntimeError("Failed to connect to the database.")

def insert_extracted_text(extracted_text):
    """Insert the extracted text into the ExtractedTexts table."""
    conn_str = os.getenv('SQL_CONNECTION_STRING')
    try:
        with pyodbc.connect(conn_str) as conn:
            cursor = conn.cursor()
            cursor.execute("INSERT INTO ExtractedTexts (Text) VALUES (?)", (extracted_text,))
            conn.commit()
    except Exception as e:
        logging.error(f"Failed to insert data into the database: {e}")
        raise RuntimeError("Failed to insert extracted text into the database.")



def funcextraction(req: HttpRequest) -> HttpResponse:
    """Main entry point for the Azure Function."""
    logging.info('Processing image extraction request.')

    try:
        # Create the database table if it does not exist
        create_table_if_not_exists()

        # Get the image path from the request parameters
        image_path = req.params.get('image_path')
        if not image_path:
            return HttpResponse("Please provide an image path.", status_code=400)

        # Initialize the ImageProcessor with the provided image path
        processor = ImageProcessor(image_path)

        # Validate the image format
        processor.validate_image_format()

        # Load the image, convert to PNG, and encode to base64
        processor.load_image()
        png_path = processor.convert_to_png()
        encoded_image = processor.encode_image_to_base64()

        # Prepare the API request to OpenAI
        API_KEY = os.getenv('OPENAI_API_KEY')
        if not API_KEY:
            raise ValueError("OpenAI API key is not set in the environment variables.")

        headers = {
            "Content-Type": "application/json",
            "api-key": API_KEY,
        }

        # Updated prompt for text extraction
        payload = {
            "messages": [
                {
                    "role": "system",
                    "content": [
                        {
                            "type": "text",
                            "text": "You are a specialized data extractor designed to analyze images of pricing menus from the pub industry."
                        }
                    ]
                },
                {
                    "role": "user",
                    "content": [
                        {
                            "type": "image_url",
                            "image_url": {
                                "url": f"data:image/png;base64,{encoded_image}"  # Base64 image for API
                            }
                        },
                        {
                            "type": "text",
                            "text": "Please extract all visible text from this image and show that in JSON format, focusing on both competitor information and promotional details.\n\n**Competitor Information:**\n1. **Brand**: The name of the pub or brand.\n2. **Site**: The specific location or website associated with the brand.\n3. **Postcode**: The postcode of the pub location.\n\n**Promotional Details:**\n1. **Promotion Type**: What is being offered? (e.g., \"Buy 1 get 1 free\", \"Happy Hour discounts\")\n2. **Details of the Offer**: Specify the offer details. (e.g., \"1 beer free for every beer purchased\")\n3. **Days and Times**: When is the promotion available? (e.g., \"Every Wednesday from 5 PM to 7 PM\")\n4. **Conditions**: Any specific conditions or restrictions? (e.g., \"Limited to two free beers per customer\")\n5. **Location**: Where is the promotion applicable? (e.g., \"At our downtown location\")\n6. **Expiration Date**: Is there a time limit on the promotion? (e.g., \"Valid until the end of October\")\n\nPlease present the extracted information in a structured JSON format that includes all the text, along with the competitor information and promotional details."
                        }
                    ]
                }
            ],
            "temperature": 0.7,
            "top_p": 0.95,
            "max_tokens": 4096
        }

        # Define the OpenAI API endpoint
        ENDPOINT = "https://pricingsurvey-openai.openai.azure.com/openai/deployments/gpt-4o/chat/completions?api-version=2024-02-15-preview"

        # Send the request to the OpenAI API
        response = requests.post(ENDPOINT, headers=headers, json=payload)
        response.raise_for_status()  # Raise an error for unsuccessful responses

        # Parse the response data
        response_data = response.json()
        extracted_content = response_data['choices'][0]['message']['content']

        # Insert the extracted text into the database
        insert_extracted_text(extracted_content)

        # Return the extracted content as the HTTP response
        return HttpResponse(extracted_content, status_code=200)

    except ValueError as ve:
        # Handle known validation errors gracefully
        logging.error(f"ValueError: {ve}")
        return HttpResponse(f"Error: {ve}", status_code=400)
    except RuntimeError as re:
        # Handle runtime errors like database connection issues
        logging.error(f"RuntimeError: {re}")
        return HttpResponse(f"Error: {re}", status_code=500)
    except requests.RequestException as req_err:
        # Handle errors from the API call
        logging.error(f"RequestException: {req_err}")
        return HttpResponse("Error contacting the OpenAI API.", status_code=502)
    except Exception as e:
        # Catch-all for unexpected errors
        logging.error(f"Unexpected error: {e}")
        return HttpResponse(f"Error: {e}", status_code=500)
    
    